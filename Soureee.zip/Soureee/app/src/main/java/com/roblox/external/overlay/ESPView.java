package com.roblox.external.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import com.roblox.external.core.FeatureEngine;
import com.roblox.external.core.Offsets;
import com.roblox.external.menu.FloatingMenuService;

import java.util.List;

public class ESPView extends View {

    private final Paint boxPaint = new Paint();
    private final Paint linePaint = new Paint();
    private final Paint textPaint = new Paint();
    private final Paint bgPaint = new Paint();

    public ESPView(Context context) {
        super(context);
        setBackgroundColor(Color.TRANSPARENT);
        boxPaint.setColor(0xFF00E676);
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(2f);
        boxPaint.setAntiAlias(true);
        linePaint.setColor(0xFFFFEB3B);
        linePaint.setStrokeWidth(1.5f);
        linePaint.setAntiAlias(true);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(28f);
        textPaint.setAntiAlias(true);
        bgPaint.setColor(0x88000000);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!Offsets.espEnabled) {
            postInvalidateDelayed(32);
            return;
        }
        FeatureEngine engine = FloatingMenuService.featureEngine;
        if (engine == null) {
            postInvalidateDelayed(32);
            return;
        }
        int w = getWidth();
        int h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;

        List<FeatureEngine.PlayerEsp> list = engine.getEspSnapshot();
        for (FeatureEngine.PlayerEsp p : list) {
            if (!p.valid) continue;
            // Placeholder projection — replace with real W2S when camera matrix available
            float sx = cx + (p.x * 2f);
            float sy = cy - (p.y * 2f);
            if (sx < 0 || sy < 0 || sx > w || sy > h) {
                sx = cx;
                sy = cy - 80;
            }
            float bw = 60;
            float bh = 100;
            if (Offsets.espBox) {
                canvas.drawRect(sx - bw / 2, sy - bh, sx + bw / 2, sy, boxPaint);
            }
            if (Offsets.espLine) {
                canvas.drawLine(cx, h, sx, sy, linePaint);
            }
            if (Offsets.espName || Offsets.espDistance) {
                String label = "";
                if (Offsets.espName) label += p.name;
                if (Offsets.espDistance) label += String.format(" [%.0fm]", p.distance);
                canvas.drawRect(sx - 40, sy - bh - 30, sx + 80, sy - bh - 4, bgPaint);
                canvas.drawText(label, sx - 36, sy - bh - 10, textPaint);
            }
        }

        if (Offsets.aimbotEnabled) {
            float r = Offsets.aimFov;
            Paint fov = new Paint();
            fov.setColor(0x44FF4081);
            fov.setStyle(Paint.Style.STROKE);
            fov.setStrokeWidth(2f);
            canvas.drawCircle(cx, cy, r, fov);
        }

        postInvalidateDelayed(16);
    }
}
