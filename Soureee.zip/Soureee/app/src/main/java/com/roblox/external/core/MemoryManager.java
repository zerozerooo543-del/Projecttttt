package com.roblox.external.core;

import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * External memory R/W for Dual Space / Virtual Space.
 * /proc/<pid>/mem — no root when both apps share the virtual container.
 */
public class MemoryManager {

    private static final String TAG = "RBX_Mem";
    private int pid = 0;
    private RandomAccessFile memFile = null;
    private boolean attached = false;
    private boolean canWrite = false;

    public boolean attach(int targetPid) {
        detach();
        this.pid = targetPid;
        try {
            File mem = new File("/proc/" + pid + "/mem");
            if (!mem.exists()) {
                Log.e(TAG, "mem not found pid=" + pid);
                return false;
            }
            // try RW first (some VS allow write)
            try {
                memFile = new RandomAccessFile(mem, "rw");
                canWrite = true;
            } catch (Exception e) {
                memFile = new RandomAccessFile(mem, "r");
                canWrite = false;
            }
            attached = true;
            Offsets.targetPid = pid;
            Log.i(TAG, "Attached pid=" + pid + " write=" + canWrite);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Attach fail: " + e.getMessage());
            attached = false;
            return false;
        }
    }

    public void detach() {
        try {
            if (memFile != null) memFile.close();
        } catch (Exception ignored) {}
        memFile = null;
        attached = false;
        canWrite = false;
        pid = 0;
        Offsets.targetPid = 0;
        Offsets.libBase = 0;
    }

    public boolean isAttached() {
        return attached && memFile != null;
    }

    public boolean canWrite() {
        return canWrite;
    }

    public int getPid() {
        return pid;
    }

    public long findLibraryBase(String libName) {
        if (pid <= 0) return 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader("/proc/" + pid + "/maps"));
            String line;
            long best = 0;
            while ((line = br.readLine()) != null) {
                if (!line.contains(libName)) continue;
                String[] parts = line.trim().split("\\s+");
                if (parts.length < 2) continue;
                String[] se = parts[0].split("-");
                if (se.length != 2) continue;
                long start = Long.parseUnsignedLong(se[0], 16);
                String perms = parts[1];
                // prefer executable mapping with file offset 0
                if (perms.contains("x") && parts.length > 2) {
                    long off = Long.parseUnsignedLong(parts[2], 16);
                    if (off == 0) {
                        best = start;
                        break;
                    }
                }
                if (best == 0) best = start;
            }
            br.close();
            if (best != 0) {
                Offsets.libBase = best;
                Log.i(TAG, libName + " base=0x" + Long.toHexString(best));
            }
            return best;
        } catch (Exception e) {
            Log.e(TAG, "findLibraryBase: " + e.getMessage());
            return 0;
        }
    }

    public byte[] readBytes(long address, int size) {
        if (!isAttached() || size <= 0 || size > 0x100000) return null;
        try {
            byte[] buf = new byte[size];
            memFile.seek(address);
            int n = memFile.read(buf);
            if (n <= 0) return null;
            if (n < size) {
                byte[] t = new byte[n];
                System.arraycopy(buf, 0, t, 0, n);
                return t;
            }
            return buf;
        } catch (Exception e) {
            return null;
        }
    }

    public boolean writeBytes(long address, byte[] data) {
        if (!isAttached() || !canWrite || data == null) return false;
        try {
            memFile.seek(address);
            memFile.write(data);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public int readInt(long address) {
        byte[] b = readBytes(address, 4);
        if (b == null || b.length < 4) return 0;
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    public long readLong(long address) {
        byte[] b = readBytes(address, 8);
        if (b == null || b.length < 8) return 0;
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getLong();
    }

    public float readFloat(long address) {
        byte[] b = readBytes(address, 4);
        if (b == null || b.length < 4) return 0f;
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getFloat();
    }

    public boolean writeInt(long address, int value) {
        ByteBuffer bb = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(value);
        return writeBytes(address, bb.array());
    }

    public boolean writeLong(long address, long value) {
        ByteBuffer bb = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
        bb.putLong(value);
        return writeBytes(address, bb.array());
    }

    public boolean writeFloat(long address, float value) {
        ByteBuffer bb = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        bb.putFloat(value);
        return writeBytes(address, bb.array());
    }

    /** Multi-level pointer: base + offsets chain */
    public long readPointerChain(long base, int... offsets) {
        long addr = base;
        for (int i = 0; i < offsets.length; i++) {
            if (addr == 0) return 0;
            if (i < offsets.length - 1) {
                addr = readLong(addr + offsets[i]);
            } else {
                addr = addr + offsets[i];
            }
        }
        return addr;
    }

    public float[] readVec3(long address) {
        byte[] b = readBytes(address, 12);
        if (b == null || b.length < 12) return null;
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        return new float[]{bb.getFloat(), bb.getFloat(), bb.getFloat()};
    }

    public boolean writeVec3(long address, float x, float y, float z) {
        ByteBuffer bb = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN);
        bb.putFloat(x);
        bb.putFloat(y);
        bb.putFloat(z);
        return writeBytes(address, bb.array());
    }
}
