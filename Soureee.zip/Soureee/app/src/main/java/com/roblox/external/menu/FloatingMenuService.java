package com.roblox.external.menu;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.roblox.external.core.FeatureEngine;
import com.roblox.external.core.MemoryManager;
import com.roblox.external.core.Offsets;
import com.roblox.external.core.ProcessUtils;

/**
 * Floating mod menu overlay — Dual Space compatible.
 */
public class FloatingMenuService extends Service {

    public static MemoryManager memoryManager;
    public static FeatureEngine featureEngine;

    private WindowManager windowManager;
    private View menuView;
    private View bubbleView;
    private boolean expanded = false;
    private TextView statusTv;
    private EditText pidEt;
    private EditText humanoidEt;
    private EditText hrpEt;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (memoryManager == null) memoryManager = new MemoryManager();
        if (featureEngine == null) featureEngine = new FeatureEngine(memoryManager);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    @Override
    public void onDestroy() {
        if (featureEngine != null) featureEngine.stop();
        removeViews();
        super.onDestroy();
    }

    private void removeViews() {
        try {
            if (menuView != null) windowManager.removeView(menuView);
            if (bubbleView != null) windowManager.removeView(bubbleView);
        } catch (Exception ignored) {}
        menuView = null;
        bubbleView = null;
    }

    private int overlayType() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void showBubble() {
        bubbleView = new TextView(this);
        ((TextView) bubbleView).setText("RBX");
        ((TextView) bubbleView).setTextColor(Color.WHITE);
        ((TextView) bubbleView).setTextSize(14);
        ((TextView) bubbleView).setTypeface(Typeface.DEFAULT_BOLD);
        ((TextView) bubbleView).setGravity(Gravity.CENTER);
        bubbleView.setBackgroundColor(0xCCE91E63);
        bubbleView.setPadding(28, 20, 28, 20);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 40;
        lp.y = 200;

        bubbleView.setOnTouchListener(new DragTouchListener(lp, () -> toggleMenu()));
        windowManager.addView(bubbleView, lp);
    }

    private void toggleMenu() {
        if (expanded) {
            if (menuView != null) {
                try { windowManager.removeView(menuView); } catch (Exception ignored) {}
                menuView = null;
            }
            expanded = false;
        } else {
            showMenu();
            expanded = true;
        }
    }

    private void showMenu() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xF0121212);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));
        scroll.addView(root);

        TextView title = tv("Roblox External Menu", 18, 0xFFE91E63);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);
        root.addView(tv("No-Root · Dual Space · PID attach", 11, 0xFF9E9E9E));

        statusTv = tv("Status: detached", 12, 0xFFFFEB3B);
        root.addView(statusTv);

        // PID row
        root.addView(tv("PID (auto or manual)", 11, 0xFFB0BEC5));
        pidEt = new EditText(this);
        pidEt.setHint("pid");
        pidEt.setTextColor(Color.WHITE);
        pidEt.setHintTextColor(0xFF666666);
        pidEt.setBackgroundColor(0xFF1E1E1E);
        pidEt.setSingleLine(true);
        root.addView(pidEt);

        LinearLayout row1 = hrow();
        row1.addView(btn("AUTO PID", 0xFF2962FF, v -> {
            int p = ProcessUtils.findRobloxPid();
            if (p > 0) {
                pidEt.setText(String.valueOf(p));
                toast("Found " + p);
            } else toast("Roblox PID not found");
        }));
        row1.addView(btn("ATTACH", 0xFF00C853, v -> doAttach()));
        row1.addView(btn("DETACH", 0xFFD50000, v -> {
            if (featureEngine != null) featureEngine.stop();
            if (memoryManager != null) memoryManager.detach();
            Offsets.resetRuntime();
            setStatus("detached");
        }));
        root.addView(row1);

        // Advanced addresses
        root.addView(tv("Humanoid addr hex (optional)", 11, 0xFFB0BEC5));
        humanoidEt = new EditText(this);
        humanoidEt.setHint("0x...");
        humanoidEt.setTextColor(Color.WHITE);
        humanoidEt.setHintTextColor(0xFF666666);
        humanoidEt.setBackgroundColor(0xFF1E1E1E);
        humanoidEt.setSingleLine(true);
        root.addView(humanoidEt);

        root.addView(tv("HRP addr hex (optional)", 11, 0xFFB0BEC5));
        hrpEt = new EditText(this);
        hrpEt.setHint("0x...");
        hrpEt.setTextColor(Color.WHITE);
        hrpEt.setHintTextColor(0xFF666666);
        hrpEt.setBackgroundColor(0xFF1E1E1E);
        hrpEt.setSingleLine(true);
        root.addView(hrpEt);

        root.addView(btn("APPLY ADDR", 0xFF7C4DFF, v -> {
            try {
                String h = humanoidEt.getText().toString().trim().replace("0x", "");
                String r = hrpEt.getText().toString().trim().replace("0x", "");
                if (!h.isEmpty()) {
                    long a = Long.parseUnsignedLong(h, 16);
                    featureEngine.setManualHumanoid(a);
                    Offsets.humanoid = a;
                }
                if (!r.isEmpty()) {
                    long a = Long.parseUnsignedLong(r, 16);
                    featureEngine.setManualHRP(a);
                    Offsets.humanoidRootPart = a;
                }
                toast("Addresses applied");
                setStatus("hum=0x" + Long.toHexString(Offsets.humanoid)
                        + " hrp=0x" + Long.toHexString(Offsets.humanoidRootPart));
            } catch (Exception e) {
                toast("Bad hex");
            }
        }));

        root.addView(btn("FORCE SCAN Humanoid/HRP", 0xFFFF6D00, v -> {
            if (!memoryManager.isAttached()) {
                toast("Attach first");
                return;
            }
            // clear so engine rescans
            if (humanoidEt.getText().toString().trim().isEmpty()) {
                featureEngine.setManualHumanoid(0);
                Offsets.humanoid = 0;
            }
            if (hrpEt.getText().toString().trim().isEmpty()) {
                featureEngine.setManualHRP(0);
                Offsets.humanoidRootPart = 0;
            }
            if (!featureEngineIsRunning()) {
                featureEngine.start();
            }
            toast("Scanning... wait 2-5s then toggle Speed");
            setStatus("scanning Humanoid/HRP...");
            // delayed status refresh
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                setStatus(featureEngine.statusLine() + " | write=" + memoryManager.canWrite());
                if (Offsets.humanoid != 0) {
                    humanoidEt.setText("0x" + Long.toHexString(Offsets.humanoid));
                }
                if (Offsets.humanoidRootPart != 0) {
                    hrpEt.setText("0x" + Long.toHexString(Offsets.humanoidRootPart));
                }
                toast(Offsets.humanoid != 0 ? "Found Humanoid" : "Not found — try in-game spawn");
            }, 3500);
        }));

        // Features
        root.addView(section("MOVEMENT"));
        root.addView(sw("Speed Hack", Offsets.speedEnabled, (b, c) -> Offsets.speedEnabled = c));
        root.addView(seek("WalkSpeed", 16, 200, (int) Offsets.walkSpeedValue, v -> Offsets.walkSpeedValue = v));
        root.addView(sw("Jump Power", Offsets.jumpEnabled, (b, c) -> Offsets.jumpEnabled = c));
        root.addView(seek("JumpPower", 50, 300, (int) Offsets.jumpPowerValue, v -> Offsets.jumpPowerValue = v));
        root.addView(sw("Infinite Jump", Offsets.infiniteJump, (b, c) -> Offsets.infiniteJump = c));
        root.addView(sw("Fly", Offsets.flyEnabled, (b, c) -> Offsets.flyEnabled = c));
        root.addView(seek("FlySpeed", 10, 150, (int) Offsets.flySpeedValue, v -> Offsets.flySpeedValue = v));
        root.addView(sw("NoClip (exp)", Offsets.noClipEnabled, (b, c) -> Offsets.noClipEnabled = c));

        root.addView(section("PLAYER"));
        root.addView(sw("God Mode / Inf HP", Offsets.godMode, (b, c) -> Offsets.godMode = c));

        root.addView(section("VISUAL"));
        root.addView(sw("ESP Enable", Offsets.espEnabled, (b, c) -> Offsets.espEnabled = c));
        root.addView(sw("ESP Box", Offsets.espBox, (b, c) -> Offsets.espBox = c));
        root.addView(sw("ESP Line", Offsets.espLine, (b, c) -> Offsets.espLine = c));
        root.addView(sw("ESP Name", Offsets.espName, (b, c) -> Offsets.espName = c));
        root.addView(sw("ESP Distance", Offsets.espDistance, (b, c) -> Offsets.espDistance = c));

        root.addView(section("COMBAT"));
        root.addView(sw("AimBot", Offsets.aimbotEnabled, (b, c) -> Offsets.aimbotEnabled = c));
        root.addView(seek("Aim FOV", 20, 360, (int) Offsets.aimFov, v -> Offsets.aimFov = v));
        root.addView(seek("Aim Smooth", 1, 20, (int) Offsets.aimSmooth, v -> Offsets.aimSmooth = v));

        root.addView(btn("START ENGINE", 0xFFE91E63, v -> {
            if (!memoryManager.isAttached()) {
                toast("Attach first");
                return;
            }
            featureEngine.start();
            setStatus("engine ON | scanning if needed | write=" + memoryManager.canWrite());
            toast("Engine ON — auto-scan Humanoid if empty");
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                setStatus(featureEngine.statusLine());
                if (Offsets.humanoid != 0) {
                    humanoidEt.setText("0x" + Long.toHexString(Offsets.humanoid));
                }
                if (Offsets.humanoidRootPart != 0) {
                    hrpEt.setText("0x" + Long.toHexString(Offsets.humanoidRootPart));
                }
            }, 3500);
        }));
        root.addView(btn("STOP ENGINE", 0xFF616161, v -> {
            featureEngine.stop();
            setStatus("engine OFF | attached=" + memoryManager.isAttached());
        }));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                dp(300),
                dp(480),
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 60;
        lp.y = 120;
        menuView = scroll;
        windowManager.addView(menuView, lp);
    }

    private void doAttach() {
        int pid;
        try {
            pid = Integer.parseInt(pidEt.getText().toString().trim());
        } catch (Exception e) {
            pid = ProcessUtils.findRobloxPid();
            if (pid > 0) pidEt.setText(String.valueOf(pid));
        }
        if (pid <= 0) {
            toast("Invalid PID");
            return;
        }
        boolean ok = memoryManager.attach(pid);
        if (!ok) {
            setStatus("attach FAILED pid=" + pid);
            toast("Attach failed");
            return;
        }
        long base = memoryManager.findLibraryBase(Offsets.LIB_NAME);
        setStatus("OK pid=" + pid + " base=0x" + Long.toHexString(base)
                + " write=" + memoryManager.canWrite());
        toast("Attached");
    }

    private void setStatus(String s) {
        if (statusTv != null) statusTv.setText("Status: " + s);
    }

    // --- UI helpers ---
    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView tv(String t, float size, int color) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(size);
        tv.setTextColor(color);
        tv.setPadding(0, dp(4), 0, dp(2));
        return tv;
    }

    private TextView section(String t) {
        TextView tv = tv("── " + t + " ──", 13, 0xFF80CBC4);
        tv.setPadding(0, dp(10), 0, dp(4));
        return tv;
    }

    private LinearLayout hrow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private Button btn(String t, int bg, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextSize(11);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(bg);
        b.setOnClickListener(l);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    private Switch sw(String label, boolean init, CompoundButton.OnCheckedChangeListener l) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setChecked(init);
        s.setOnCheckedChangeListener(l);
        s.setPadding(0, dp(4), 0, dp(4));
        return s;
    }

    private LinearLayout seek(String label, int min, int max, int cur, final IntConsumer cons) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView tv = tv(label + ": " + cur, 11, 0xFFB0BEC5);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int v = progress + min;
                tv.setText(label + ": " + v);
                cons.accept(v);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        box.addView(tv);
        box.addView(sb);
        return box;
    }

    private interface IntConsumer { void accept(int v); }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private class DragTouchListener implements View.OnTouchListener {
        private final WindowManager.LayoutParams lp;
        private final Runnable click;
        private int ix, iy;
        private float tx, ty;
        private boolean moved;

        DragTouchListener(WindowManager.LayoutParams lp, Runnable click) {
            this.lp = lp;
            this.click = click;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    ix = lp.x;
                    iy = lp.y;
                    tx = e.getRawX();
                    ty = e.getRawY();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (e.getRawX() - tx);
                    int dy = (int) (e.getRawY() - ty);
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true;
                    lp.x = ix + dx;
                    lp.y = iy + dy;
                    windowManager.updateViewLayout(v, lp);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved && click != null) click.run();
                    return true;
            }
            return false;
        }
    }
}
