package com.roblox.external.core;

/**
 * Offsets aligned to functions.txt from accurate libroblox.so dump.
 *
 * Dump header:
 *   PID lib=libroblox.so
 *   baseVA from runtime maps (fill at attach)
 *   fileSize≈109977600  mode=ACCURATE_OFFSET
 *
 * All STR_* values are FILE OFFSETS inside the dumped SO.
 * Absolute VA = libBase + STR_*
 *
 * These are primarily string / symbol anchors for scanning and RE.
 * Instance field offsets (Humanoid_*) still need per-version validation
 * via RE / pointer scan — anchors below speed that up.
 */
public class Offsets {

    public static int targetPid = 0;
    public static long libBase = 0;
    public static final String LIB_NAME = "libroblox.so";
    public static final String TARGET_PACKAGE = "com.roblox.client";

    // ============================================================
    // STRING / SYMBOL FILE OFFSETS  (from functions.txt — exact)
    // Absolute VA = libBase + offset
    // ============================================================

    // --- Core services / instances ---
    public static final long STR_DataModel              = 0x3b4a89L;
    public static final long STR_Workspace              = 0x29e4d3L;
    public static final long STR_Players                = 0x45fb8bL;
    public static final long STR_LocalPlayer            = 0x25630eL; // "localPlayer"
    public static final long STR_Character              = 0x30f3c4L;
    public static final long STR_CharacterAdded         = 0x44f839L;
    public static final long STR_Humanoid               = 0x283127L;
    public static final long STR_HumanoidRootPart       = 0x5229d6L;
    public static final long STR_RootPart               = 0x2a0b1aL;
    public static final long STR_Camera                 = 0x37fa92L;
    public static final long STR_GetService             = 0x256924L;
    public static final long STR_FindFirstChild         = 0x3c34dfL;
    public static final long STR_GetChildren            = 0x48a0abL;
    public static final long STR_Name                   = 0x394291L;
    public static final long STR_Parent                 = 0x53ebc4L;
    public static final long STR_ClassName              = 0x53ebf3L;

    // --- Humanoid properties (string anchors) ---
    public static final long STR_WalkSpeed              = 0x2fead6L; // "walkSpeed"
    public static final long STR_CharacterWalkSpeed     = 0x51271fL;
    public static final long STR_JumpPower              = 0x4625c4L;
    public static final long STR_CharacterJumpPower     = 0x5669bcL;
    public static final long STR_JumpHeight             = 0x2f46e7L;
    public static final long STR_CalculateJumpPower     = 0x4f7b47L;
    public static final long STR_UseJumpPower           = 0x39be5fL;
    public static final long STR_CharacterUseJumpPower  = 0x3c03dfL;
    public static final long STR_HipHeight              = 0x499739L;
    public static final long STR_Health                 = 0x5417c3L;
    public static final long STR_MaxHealth              = 0x2305fdL;
    public static final long STR_Sit                    = 0x30a3014L; // "Sit8" nearby
    public static final long STR_PlatformStand          = 0x346f0aL;
    public static final long STR_AutoJumpEnabled        = 0x40c3a6L;
    public static final long STR_doAutoJump             = 0x2f32b2L;
    public static final long STR_Jump                   = 0x3d34dcL;
    public static final long STR_Jumping                = 0x2f32bdL;
    public static final long STR_MoveDirection          = 0x2f4dd0L;
    public static final long STR_WalkToPoint            = 0x5792faL;
    public static final long STR_WalkToPart             = 0x2a0eb3L;
    public static final long STR_FloorMaterial          = 0x445316L;
    public static final long STR_TakeDamage             = 0x24cae8L; // "takeDamage"
    public static final long STR_GetState               = 0x3b742aL;
    public static final long STR_ChangeState            = 0x462a29L;
    public static final long STR_EvaluateStateMachine   = 0x524f0eL;
    public static final long STR_RigType                = 0x5417caL;
    public static final long STR_TargetPoint            = 0x346f18L;

    // --- BasePart / physics ---
    public static final long STR_CFrame                 = 0x22a390L;
    public static final long STR_Position               = 0x22e240L;
    public static final long STR_characterPosition      = 0x460766L;
    public static final long STR_Velocity               = 0x28e7a4L;
    public static final long STR_RotVelocity            = 0x273512L;
    public static final long STR_AssemblyLinearVelocity = 0x487f3dL;
    public static final long STR_AssemblyAngularVelocity= 0x5673fcL;
    public static final long STR_Size                   = 0x4e78b8L;
    public static final long STR_Orientation            = 0x4be979L;
    public static final long STR_Anchored               = 0x2bd26aL;
    public static final long STR_CanCollide             = 0x36e03aL;
    public static final long STR_Transparency           = 0x3297bcL;
    public static final long STR_PrimaryPart            = 0x36e0ddL;
    public static final long STR_GetPivot               = 0x46c383L;
    public static final long STR_PivotTo                = 0x59ed4bL;
    public static final long STR_GetPrimaryPartCFrame   = 0x4f7c92L;
    public static final long STR_SetPrimaryPartCFrame   = 0x3a5bddL;
    public static final long STR_GetBoundingBox         = 0x27357eL;

    // --- Camera ---
    public static final long STR_FieldOfView            = 0x28db57L;
    public static final long STR_CameraFov              = 0x44ce37L;
    public static final long STR_CameraPos              = 0x2fbf8bL;
    public static final long STR_cameraPosition         = 0x2c2d88L;
    public static final long STR_CameraSubject          = 0x28e5cbL;
    public static final long STR_CameraOffset           = 0x428af1L;
    public static final long STR_CameraMode             = 0x2bc025L;
    public static final long STR_WorldToScreenPoint     = 0x44fc3dL;
    public static final long STR_WorldToViewportPoint   = 0x3c08d8L;

    // --- Body parts ---
    public static final long STR_Torso                  = 0x328991L;
    public static final long STR_UpperTorso             = 0x2b9af3L;
    public static final long STR_LowerTorso             = 0x4cfa54L;

    // --- Player meta ---
    public static final long STR_UserId                 = 0x4cafe9L;
    public static final long STR_DisplayName            = 0x524f02L;
    public static final long STR_AccountAge             = 0x2e1c81L;
    public static final long STR_RespawnLocation        = 0x54ab5eL;
    public static final long STR_DisplayDistanceType    = 0x47e87dL;
    public static final long STR_NameOcclusion          = 0x5949ffL;

    // ============================================================
    // RUNTIME RESOLVED POINTERS (filled after attach / scan)
    // ============================================================
    public static long dataModel = 0;
    public static long workspace = 0;
    public static long players = 0;
    public static long localPlayer = 0;
    public static long character = 0;
    public static long humanoid = 0;
    public static long humanoidRootPart = 0;
    public static long camera = 0;

    /**
     * Humanoid instance field offsets (relative to Humanoid*).
     * NOT the same as string file offsets above.
     * Seed values — refine with CE / IDA / live pointer scan per build.
     * Cross-check using STR_WalkSpeed etc. as property-name anchors in reflection.
     */
    public static int Humanoid_WalkSpeed   = 0x1DC;  // float — align via walkSpeed reflection
    public static int Humanoid_JumpPower   = 0x1E0;  // float
    public static int Humanoid_JumpHeight  = 0x1E4;  // float
    public static int Humanoid_HipHeight   = 0x1E8;  // float
    public static int Humanoid_Health      = 0x19C;  // float
    public static int Humanoid_MaxHealth   = 0x1A0;  // float
    public static int Humanoid_Sit         = 0x1F0;  // bool/byte
    public static int Humanoid_PlatformStand = 0x1F1;
    public static int Humanoid_AutoJumpEnabled = 0x1F2;
    public static int Humanoid_UseJumpPower = 0x1F3;
    public static int Humanoid_MoveDirection = 0x200; // Vector3
    public static int Humanoid_RootPart    = 0x1B0;  // pointer
    public static int Humanoid_DisplayName = 0x0;    // optional

    // BasePart / HRP relative
    public static int BasePart_Position    = 0x14C;  // Vector3 — refine
    public static int BasePart_CFrame      = 0x140;  // CFrame (12–16 floats engine-dependent)
    public static int BasePart_Size        = 0x170;
    public static int BasePart_Velocity    = 0x17C;  // Vector3
    public static int BasePart_RotVelocity = 0x188;
    public static int BasePart_Anchored    = 0x1A0;  // byte
    public static int BasePart_CanCollide  = 0x1A1;
    public static int BasePart_Transparency= 0x1A4;  // float

    // Camera relative
    public static int Camera_FieldOfView   = 0x168;  // float
    public static int Camera_CFrame        = 0x140;
    public static int Camera_Subject       = 0x180;  // pointer

    // ============================================================
    // FEATURE STATE
    // ============================================================
    public static boolean espEnabled = false;
    public static boolean espBox = true;
    public static boolean espLine = true;
    public static boolean espName = true;
    public static boolean espDistance = true;
    public static boolean aimbotEnabled = false;
    public static boolean speedEnabled = false;
    public static boolean jumpEnabled = false;
    public static boolean flyEnabled = false;
    public static boolean noClipEnabled = false;
    public static boolean infiniteJump = false;
    public static boolean godMode = false;

    public static float walkSpeedValue = 50f;
    public static float jumpPowerValue = 100f;
    public static float flySpeedValue = 50f;
    public static float aimFov = 120f;
    public static float aimSmooth = 5f;

    public static void resetRuntime() {
        dataModel = 0;
        workspace = 0;
        players = 0;
        localPlayer = 0;
        character = 0;
        humanoid = 0;
        humanoidRootPart = 0;
        camera = 0;
    }

    /** Helper: file offset → VA */
    public static long va(long fileOffset) {
        return libBase != 0 ? libBase + fileOffset : 0;
    }
}
