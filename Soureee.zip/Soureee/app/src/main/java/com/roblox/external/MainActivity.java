package com.roblox.external;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.roblox.external.menu.FloatingMenuService;
import com.roblox.external.overlay.OverlayService;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D0D0D);
        root.setPadding(48, 64, 48, 48);

        TextView title = new TextView(this);
        title.setText("Roblox External\nNo-Root / Dual Space");
        title.setTextColor(0xFFE91E63);
        title.setTextSize(22);
        title.setPadding(0, 0, 0, 24);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText(
                "1. Install Roblox + this APK inside Dual Space\n"
                        + "2. Grant OVERLAY permission\n"
                        + "3. Start Overlay + Menu services\n"
                        + "4. Open floating RBX bubble\n"
                        + "5. AUTO PID → ATTACH → START ENGINE\n"
                        + "6. Toggle Speed / Jump / Fly / ESP / Aim\n\n"
                        + "Lib: libroblox.so\n"
                        + "Update Offsets.java after each dump\n"
                        + "Humanoid/HRP addr can be set manually"
        );
        info.setTextColor(0xFFB0BEC5);
        info.setTextSize(13);
        info.setPadding(0, 0, 0, 24);
        root.addView(info);

        Button perm = new Button(this);
        perm.setText("GRANT OVERLAY PERMISSION");
        perm.setOnClickListener(v -> requestOverlay());
        root.addView(perm);

        Button startOverlay = new Button(this);
        startOverlay.setText("START ESP OVERLAY");
        startOverlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant overlay first", Toast.LENGTH_SHORT).show();
                requestOverlay();
                return;
            }
            startService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "ESP overlay started", Toast.LENGTH_SHORT).show();
        });
        root.addView(startOverlay);

        Button startMenu = new Button(this);
        startMenu.setText("START FLOATING MENU");
        startMenu.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant overlay first", Toast.LENGTH_SHORT).show();
                requestOverlay();
                return;
            }
            startService(new Intent(this, FloatingMenuService.class));
            Toast.makeText(this, "Menu started — tap RBX bubble", Toast.LENGTH_SHORT).show();
        });
        root.addView(startMenu);

        Button stop = new Button(this);
        stop.setText("STOP ALL SERVICES");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            stopService(new Intent(this, FloatingMenuService.class));
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop);

        setContentView(root);
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }
}
