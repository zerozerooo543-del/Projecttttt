package com.roblox.external.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class ProcessUtils {

    public static class ProcInfo {
        public int pid;
        public String name;
        public ProcInfo(int pid, String name) {
            this.pid = pid;
            this.name = name;
        }
        @Override
        public String toString() {
            return pid + "  " + name;
        }
    }

    public static List<ProcInfo> scan(String filter) {
        List<ProcInfo> out = new ArrayList<>();
        File proc = new File("/proc");
        File[] dirs = proc.listFiles();
        if (dirs == null) return out;
        String f = filter == null ? "" : filter.toLowerCase();
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            String n = d.getName();
            if (!n.matches("\\d+")) continue;
            int pid;
            try {
                pid = Integer.parseInt(n);
            } catch (Exception e) {
                continue;
            }
            String cmd = readCmd(pid);
            if (cmd == null || cmd.isEmpty()) continue;
            if (cmd.startsWith("/system") || cmd.equals("zygote") || cmd.equals("zygote64")) continue;
            if (!f.isEmpty() && !cmd.toLowerCase().contains(f)) continue;
            // prefer roblox
            if (f.isEmpty()) {
                String lc = cmd.toLowerCase();
                if (!(lc.contains("roblox") || lc.contains("com.roblox") || cmd.contains("."))) continue;
            }
            out.add(new ProcInfo(pid, cmd));
        }
        out.sort((a, b) -> Integer.compare(a.pid, b.pid));
        return out;
    }

    public static int findRobloxPid() {
        List<ProcInfo> list = scan("roblox");
        if (!list.isEmpty()) return list.get(0).pid;
        list = scan("com.roblox.client");
        if (!list.isEmpty()) return list.get(0).pid;
        return -1;
    }

    private static String readCmd(int pid) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("/proc/" + pid + "/cmdline"));
            String line = br.readLine();
            br.close();
            if (line == null) return null;
            return line.replace('\0', ' ').trim();
        } catch (Exception e) {
            return null;
        }
    }
}
