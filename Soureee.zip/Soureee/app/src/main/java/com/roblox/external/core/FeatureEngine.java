package com.roblox.external.core;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Feature engine with auto Humanoid/HRP resolver.
 *
 * Attach status from user: pid OK, base=0x733e1c1000, write=true
 * Problem: Humanoid/HRP empty → Speed/Jump/Fly no target.
 *
 * Fix: scan readable heap-like regions for float patterns matching
 * default WalkSpeed(16) / JumpPower(50) / MaxHealth(100) clusters,
 * then lock those instance addresses for writes.
 */
public class FeatureEngine implements Runnable {

    private static final String TAG = "RBX_Feat";
    private final MemoryManager mem;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread thread;
    private long manualHumanoid = 0;
    private long manualHRP = 0;
    private long lastScanMs = 0;
    private int tickCount = 0;

    public static class PlayerEsp {
        public float x, y, z;
        public float sx, sy;
        public String name;
        public float distance;
        public boolean valid;
    }

    private final List<PlayerEsp> espList = new ArrayList<>();

    public FeatureEngine(MemoryManager mem) {
        this.mem = mem;
    }

    public void setManualHumanoid(long addr) {
        manualHumanoid = addr;
        Offsets.humanoid = addr;
        Log.i(TAG, "manual Humanoid=0x" + Long.toHexString(addr));
    }

    public void setManualHRP(long addr) {
        manualHRP = addr;
        Offsets.humanoidRootPart = addr;
        Log.i(TAG, "manual HRP=0x" + Long.toHexString(addr));
    }

    public void start() {
        if (running.get()) return;
        running.set(true);
        lastScanMs = 0;
        thread = new Thread(this, "RBX-FeatureEngine");
        thread.start();
    }

    public void stop() {
        running.set(false);
        if (thread != null) {
            try { thread.join(500); } catch (Exception ignored) {}
            thread = null;
        }
    }

    public List<PlayerEsp> getEspSnapshot() {
        synchronized (espList) {
            return new ArrayList<>(espList);
        }
    }

    @Override
    public void run() {
        Log.i(TAG, "FeatureEngine started write=" + mem.canWrite()
                + " base=0x" + Long.toHexString(Offsets.libBase));
        while (running.get()) {
            try {
                if (!mem.isAttached()) {
                    Thread.sleep(400);
                    continue;
                }
                if (Offsets.libBase == 0) {
                    mem.findLibraryBase(Offsets.LIB_NAME);
                }
                // auto-resolve every ~2s if missing
                long now = System.currentTimeMillis();
                if ((Offsets.humanoid == 0 && manualHumanoid == 0)
                        || (Offsets.humanoidRootPart == 0 && manualHRP == 0)) {
                    if (now - lastScanMs > 2000) {
                        lastScanMs = now;
                        autoResolveInstances();
                    }
                }
                tickFeatures();
                tickCount++;
                Thread.sleep(16);
            } catch (InterruptedException ie) {
                break;
            } catch (Exception e) {
                Log.w(TAG, "tick: " + e.getMessage());
                try { Thread.sleep(200); } catch (Exception ignored) {}
            }
        }
        Log.i(TAG, "FeatureEngine stopped");
    }

    /**
     * Heuristic scan: look for Humanoid-like float clusters in anonymous maps.
     * Pattern near Humanoid:
     *   Health≈100, MaxHealth≈100, WalkSpeed≈16, JumpPower≈50 (defaults)
     * We scan /proc/pid/maps for rw-p anonymous regions and probe floats.
     */
    private void autoResolveInstances() {
        if (!mem.isAttached()) return;
        Log.i(TAG, "autoResolve scan...");
        List<long[]> regions = listRwRegions();
        long foundHumanoid = 0;
        long foundHrp = 0;
        int checked = 0;

        for (long[] rg : regions) {
            long start = rg[0];
            long end = rg[1];
            long size = end - start;
            // skip tiny / huge
            if (size < 0x1000 || size > 64L * 1024 * 1024) continue;
            // sample every 0x1000 aligned block, read 0x200 bytes
            for (long addr = start; addr + 0x200 < end; addr += 0x1000) {
                if (checked++ > 8000) break; // budget
                byte[] block = mem.readBytes(addr, 0x200);
                if (block == null || block.length < 0x200) continue;

                // search float cluster WalkSpeed=16, JumpPower=50 within window
                int hit = findHumanoidPattern(block);
                if (hit >= 0) {
                    long candidate = addr + hit;
                    // validate: re-read floats
                    float ws = mem.readFloat(candidate + Offsets.Humanoid_WalkSpeed);
                    float jp = mem.readFloat(candidate + Offsets.Humanoid_JumpPower);
                    float hp = mem.readFloat(candidate + Offsets.Humanoid_Health);
                    float mx = mem.readFloat(candidate + Offsets.Humanoid_MaxHealth);
                    if (isPlausibleHumanoid(ws, jp, hp, mx)) {
                        foundHumanoid = candidate;
                        Log.i(TAG, String.format(
                                "Humanoid candidate 0x%x ws=%.1f jp=%.1f hp=%.1f max=%.1f",
                                candidate, ws, jp, hp, mx));
                        // try find HRP pointer field
                        long maybePtr = mem.readLong(candidate + Offsets.Humanoid_RootPart);
                        if (maybePtr > 0x10000000L && maybePtr < 0x800000000000L) {
                            float[] pos = mem.readVec3(maybePtr + Offsets.BasePart_Position);
                            if (pos != null && isPlausiblePos(pos)) {
                                foundHrp = maybePtr;
                                Log.i(TAG, "HRP via Humanoid.RootPart 0x" + Long.toHexString(maybePtr));
                            }
                        }
                        break;
                    }
                }
            }
            if (foundHumanoid != 0) break;
        }

        // fallback HRP: scan for Position-like Vector3 near character (y between -50..500)
        if (foundHrp == 0 && foundHumanoid != 0) {
            foundHrp = scanNearbyHRP(foundHumanoid);
        }

        if (foundHumanoid != 0 && manualHumanoid == 0) {
            Offsets.humanoid = foundHumanoid;
        }
        if (foundHrp != 0 && manualHRP == 0) {
            Offsets.humanoidRootPart = foundHrp;
        }
        Log.i(TAG, "autoResolve done humanoid=0x" + Long.toHexString(Offsets.humanoid)
                + " hrp=0x" + Long.toHexString(Offsets.humanoidRootPart));
    }

    private boolean isPlausibleHumanoid(float ws, float jp, float hp, float mx) {
        // defaults: WalkSpeed 16, JumpPower 50, Health/MaxHealth 100
        // allow range while player may already be modified
        boolean speedOk = ws >= 8f && ws <= 200f;
        boolean jumpOk = jp >= 20f && jp <= 300f;
        boolean healthOk = hp > 0f && hp <= 10000f && mx >= 1f && mx <= 10000f;
        return speedOk && jumpOk && healthOk;
    }

    private boolean isPlausiblePos(float[] p) {
        if (p == null) return false;
        // roblox world coords vary; reject NaN/inf/extreme
        for (float v : p) {
            if (Float.isNaN(v) || Float.isInfinite(v) || Math.abs(v) > 1e7f) return false;
        }
        return true;
    }

    /**
     * Look for float 16.0f near float 50.0f within Humanoid field layout window.
     * Layout assumption from Offsets:
     *   Health @ 0x19C, MaxHealth @ 0x1A0, WalkSpeed @ 0x1DC, JumpPower @ 0x1E0
     * So relative WalkSpeed-Health = 0x1DC-0x19C = 0x40
     */
    private int findHumanoidPattern(byte[] block) {
        // scan for float 16.0f (0x41800000 LE) as WalkSpeed candidate
        final int WS = floatBits(16f);
        final int JP = floatBits(50f);
        final int HP = floatBits(100f);

        for (int i = 0; i + 0x1E4 + 4 <= block.length; i += 4) {
            int at = le32(block, i);
            // candidate as base (Humanoid*) where WalkSpeed field matches
            int wsOff = Offsets.Humanoid_WalkSpeed;
            int jpOff = Offsets.Humanoid_JumpPower;
            int hpOff = Offsets.Humanoid_Health;
            int mxOff = Offsets.Humanoid_MaxHealth;
            if (i + Math.max(Math.max(wsOff, jpOff), Math.max(hpOff, mxOff)) + 4 > block.length)
                continue;

            int ws = le32(block, i + wsOff);
            int jp = le32(block, i + jpOff);
            int hp = le32(block, i + hpOff);
            int mx = le32(block, i + mxOff);

            // match defaults OR already-boosted ranges via bit patterns soft check
            float fws = Float.intBitsToFloat(ws);
            float fjp = Float.intBitsToFloat(jp);
            float fhp = Float.intBitsToFloat(hp);
            float fmx = Float.intBitsToFloat(mx);
            if (isPlausibleHumanoid(fws, fjp, fhp, fmx)) {
                // extra: MaxHealth roughly >= Health
                if (fmx + 0.1f >= fhp) return i;
            }
            // tight match defaults
            if (ws == WS && (jp == JP || Float.intBitsToFloat(jp) == 50f)
                    && (hp == HP || mx == HP)) {
                return i;
            }
        }
        return -1;
    }

    private long scanNearbyHRP(long humanoid) {
        // probe pointer-sized slots around humanoid for a BasePart-like object
        for (int off = 0x100; off < 0x280; off += 8) {
            long ptr = mem.readLong(humanoid + off);
            if (ptr < 0x10000000L || ptr > 0x800000000000L) continue;
            float[] pos = mem.readVec3(ptr + Offsets.BasePart_Position);
            if (pos != null && isPlausiblePos(pos)) {
                // size sometimes ~2,2,1 for HRP
                float[] size = mem.readVec3(ptr + Offsets.BasePart_Size);
                if (size != null && size[0] > 0.1f && size[0] < 20f) {
                    Log.i(TAG, "HRP scan off=0x" + Integer.toHexString(off)
                            + " ptr=0x" + Long.toHexString(ptr));
                    Offsets.Humanoid_RootPart = off; // learn offset
                    return ptr;
                }
            }
        }
        return 0;
    }

    private List<long[]> listRwRegions() {
        List<long[]> out = new ArrayList<>();
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader("/proc/" + mem.getPid() + "/maps"));
            String line;
            while ((line = br.readLine()) != null) {
                // prefer anonymous rw-
                if (!(line.contains("rw-p") || line.contains("rw-s"))) continue;
                if (line.contains("libroblox") || line.contains(".so")) continue;
                String[] parts = line.trim().split("\\s+");
                if (parts.length < 2) continue;
                String[] se = parts[0].split("-");
                if (se.length != 2) continue;
                long s = Long.parseUnsignedLong(se[0], 16);
                long e = Long.parseUnsignedLong(se[1], 16);
                // typical app heap / anonymous
                if (s < 0x10000000L) continue;
                out.add(new long[]{s, e});
            }
            br.close();
        } catch (Exception e) {
            Log.w(TAG, "maps: " + e.getMessage());
        }
        // larger regions first (more likely DataModel heap)
        out.sort((a, b) -> Long.compare((b[1] - b[0]), (a[1] - a[0])));
        return out;
    }

    private void tickFeatures() {
        long humanoid = resolveHumanoid();
        long hrp = resolveHRP();

        if (humanoid != 0 && mem.canWrite()) {
            if (Offsets.speedEnabled) {
                mem.writeFloat(humanoid + Offsets.Humanoid_WalkSpeed, Offsets.walkSpeedValue);
            }
            if (Offsets.jumpEnabled) {
                mem.writeFloat(humanoid + Offsets.Humanoid_JumpPower, Offsets.jumpPowerValue);
                mem.writeFloat(humanoid + Offsets.Humanoid_JumpHeight, Offsets.jumpPowerValue * 0.5f);
            }
            if (Offsets.infiniteJump) {
                mem.writeFloat(humanoid + Offsets.Humanoid_JumpPower,
                        Math.max(Offsets.jumpPowerValue, 100f));
            }
            if (Offsets.godMode) {
                float max = mem.readFloat(humanoid + Offsets.Humanoid_MaxHealth);
                if (max < 1f) max = 100f;
                mem.writeFloat(humanoid + Offsets.Humanoid_Health, max);
            }
            if (Offsets.noClipEnabled && hrp != 0) {
                mem.writeInt(hrp + Offsets.BasePart_CanCollide, 0);
            }
        }

        if (hrp != 0 && mem.canWrite() && Offsets.flyEnabled) {
            float[] pos = mem.readVec3(hrp + Offsets.BasePart_Position);
            if (pos != null && isPlausiblePos(pos)) {
                pos[1] += Offsets.flySpeedValue * 0.016f;
                mem.writeVec3(hrp + Offsets.BasePart_Position, pos[0], pos[1], pos[2]);
                mem.writeVec3(hrp + Offsets.BasePart_Velocity, 0, 0, 0);
            }
        }

        synchronized (espList) {
            espList.clear();
            if (Offsets.espEnabled && hrp != 0) {
                float[] pos = mem.readVec3(hrp + Offsets.BasePart_Position);
                if (pos != null && isPlausiblePos(pos)) {
                    PlayerEsp pe = new PlayerEsp();
                    pe.x = pos[0];
                    pe.y = pos[1];
                    pe.z = pos[2];
                    pe.name = "Local";
                    pe.distance = 0;
                    pe.valid = true;
                    espList.add(pe);
                }
            }
        }
    }

    private long resolveHumanoid() {
        if (manualHumanoid != 0) {
            Offsets.humanoid = manualHumanoid;
            return manualHumanoid;
        }
        return Offsets.humanoid;
    }

    private long resolveHRP() {
        if (manualHRP != 0) {
            Offsets.humanoidRootPart = manualHRP;
            return manualHRP;
        }
        return Offsets.humanoidRootPart;
    }

    private static int floatBits(float f) {
        return Float.floatToIntBits(f);
    }

    private static int le32(byte[] b, int off) {
        if (off < 0 || off + 4 > b.length) return 0;
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8)
                | ((b[off + 2] & 0xFF) << 16) | ((b[off + 3] & 0xFF) << 24);
    }

    public String statusLine() {
        return String.format("hum=0x%x hrp=0x%x speed=%s jump=%s fly=%s",
                Offsets.humanoid, Offsets.humanoidRootPart,
                Offsets.speedEnabled, Offsets.jumpEnabled, Offsets.flyEnabled);
    }
}
